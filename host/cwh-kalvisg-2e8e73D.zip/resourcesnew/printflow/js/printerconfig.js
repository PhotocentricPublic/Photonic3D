var printerName = "LC Dental";
var repo = "PhotocentricPublic/Photonic3D";
