var printerName = "GC Dental";
